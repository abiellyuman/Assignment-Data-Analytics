Homework A and B — revised analysis

Run using Python 3.12:
  python -m venv .venv
  source .venv/bin/activate
  python -m pip install -r requirements.txt
  python analysis.py

Keep data/ beside analysis.py. Results are written to results.json,
forecast_results.csv and figures/. The supplied datasets are unmodified.
Their SHA256 hashes are recorded in results.json.

Homework A:
Four required numeric features; complete-case sample of 342 observations.
StandardScaler followed by PCA. Final K=3 for K-means and Ward in both
2D PC space and 4D standardized-feature space. K-means uses 50 starts and
random seed 42. The K=2..10 internal-validation scan is reported honestly:
K=2 has the highest silhouette; K=3 is the selected finer partition.
Species is used only for the subsequent external comparisons.

Homework B:
Follows the supplied Feature-Based Forecasting tutorial, adapted from an
hourly/daily cycle to monthly/annual data. Eight target-indexed predictors:
lags 1,2,3,12; trailing mean12; trailing slope12; target-month sine/cosine.
All observed predictors end at the month before the target.
Training targets end in December 2014. After the 12-month lookback, 670
training rows remain. Test: January 2015–September 2026, 141 months.
Naive baseline, LinearRegression, and RandomForestRegressor with 300 trees,
min_samples_leaf=3, random_state=0. No model retraining during testing.
These are one-month-ahead forecasts with observed monthly updates, not
one uninterrupted forecast from December 2014.

The earlier tutorial cross-check used 669 common training rows to compare
against the earlier feature set. This revised analysis needs only 12 past
months and therefore uses all 670 available tutorial-feature training rows.
This explains the small change from 0.373/0.481 to 0.374/0.481 ppm for
linear-regression MAE/RMSE. No test-based hyperparameter search is used.

analysis.py is the code attachment accompanying Homework_A_B_Revised.docx.
