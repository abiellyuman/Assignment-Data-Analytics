Homework A and B: reproducible analysis

The editable combined report is Homework_A_B_Draft.docx.
The report answers the supplied Assignment_Instruction.ipynb and combines both
homeworks as required by the Teams screenshot. No student identity was provided.

Run from any directory with Python 3.12:
  python -m venv .venv
  source .venv/bin/activate
  python -m pip install -r requirements.txt
  python analysis.py

Keep data/ next to analysis.py. Outputs: results.json, forecast_results.csv,
figures/, and console results. The source CSVs are included without modification.
The CO2 source is GitHub revision be8d6e3f2a0f0fa1e452a9bf65cf58682a38f899.
SHA256 fingerprints are stored in results.json.

Primary forecasts are one-month-ahead predictions with fixed training
coefficients and monthly observed lag updates. The recursive sensitivity
withholds all observed targets after December 2014. Model alpha and features
are fixed; no tuning on the test set is performed. Random seed: 42.

analysis.py is the Python-code attachment required by the assignment.
No solved notebook is implied. The original notebook contains instructions only.
