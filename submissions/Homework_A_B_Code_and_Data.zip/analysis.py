from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.metrics import silhouette_score, adjusted_rand_score, normalized_mutual_info_score, mean_absolute_error, mean_squared_error
from sklearn.linear_model import Ridge, LinearRegression
from sklearn.pipeline import make_pipeline
from scipy.optimize import linear_sum_assignment
import statsmodels.api as sm
BASE=Path(__file__).resolve().parent
FIG=BASE/'figures'; FIG.mkdir(exist_ok=True)
plt.rcParams.update({'figure.dpi':140,'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
def save(name):
 plt.tight_layout(); plt.savefig(FIG/name,bbox_inches='tight'); plt.close()
def km(k): return KMeans(n_clusters=k,n_init=50,random_state=42)
p=pd.read_csv(BASE/'data/penguins_raw.csv')
cols=['Culmen Length (mm)','Culmen Depth (mm)','Flipper Length (mm)','Body Mass (g)']
v=p.dropna(subset=cols).copy(); z=StandardScaler().fit_transform(v[cols]); pc=PCA().fit(z); u=pc.transform(z)[:,:2]
ks=list(range(2,11)); inertia=[]; sil=[]
for k in ks:
 m=km(k).fit(u); inertia.append(m.inertia_); sil.append(silhouette_score(u,m.labels_))
m1=km(1).fit(u)
fig,ax=plt.subplots(1,2,figsize=(9,3)); ax[0].plot([1]+ks,[m1.inertia_]+inertia,'o-'); ax[0].set(xlabel='K',ylabel='Within-cluster sum of squares'); ax[1].plot(ks,sil,'o-'); ax[1].set(xlabel='K',ylabel='Silhouette score'); save('a_k.png')
fig,ax=plt.subplots(figsize=(7,4)); ax.scatter(u[:,0],u[:,1],s=15,alpha=.7); ax.set(xlabel='PC1 score',ylabel='PC2 score'); save('a_pca.png')
models={}; labels={}
# Species first accessed only after the unsupervised K scan and illustrative K=3 models.
for space,a in [('2D',u),('4D',z)]:
 for method in ['K-means','Ward']:
  model=km(3) if method=='K-means' else AgglomerativeClustering(n_clusters=3,linkage='ward')
  lab=model.fit_predict(a); labels[space+' '+method]=lab
  models[space+' '+method]={'silhouette':float(silhouette_score(a,lab))}
for space,a in [('2D',u),('4D',z)]:
 for method in ['K-means','Ward']:
  model=km(2) if method=='K-means' else AgglomerativeClustering(n_clusters=2,linkage='ward')
  key=space+' '+method+' K=2'; lab=model.fit_predict(a); labels[key]=lab
  models[key]={'silhouette':float(silhouette_score(a,lab))}
fig,ax=plt.subplots(1,2,figsize=(9,3.3))
for a,key in zip(ax,['2D K-means K=2','2D Ward K=2']):
 a.scatter(u[:,0],u[:,1],c=labels[key],cmap='viridis',s=12); a.set(title=key,xlabel='PC1',ylabel='PC2')
save('a_selected.png')
y=v.Species.astype('category').cat.codes.to_numpy(); species=list(v.Species.astype('category').cat.categories)
for key,lab in labels.items():
 tab=pd.crosstab(pd.Series(lab,name='Cluster'),pd.Series(y,name='Species')).reindex(index=range(len(np.unique(lab))),columns=range(3),fill_value=0).to_numpy()
 rr,cc=linear_sum_assignment(-tab)
 models[key].update(ari=float(adjusted_rand_score(y,lab)),nmi=float(normalized_mutual_info_score(y,lab)),mapped_accuracy=float(tab[rr,cc].sum()/len(y)),table=tab.tolist())
fig,ax=plt.subplots(1,3,figsize=(10,3.3))
for a,key in zip(ax[:2],['2D K-means','2D Ward']):
 a.scatter(u[:,0],u[:,1],c=labels[key],cmap='viridis',s=12); a.set(title=key,xlabel='PC1',ylabel='PC2')
for i,name in enumerate(species): ax[2].scatter(u[y==i,0],u[y==i,1],s=12,label=name.split(' Penguin')[0])
ax[2].set(title='Species revealed',xlabel='PC1',ylabel='PC2'); ax[2].legend(fontsize=7); save('a_clusters.png')
# NOAA monthly target; flags in quality columns are not missing target values.
c=pd.read_csv(BASE/'data/co2_mm_mlo.csv',comment='#'); c.index=pd.to_datetime(dict(year=c.year,month=c.month,day=1)); c=c.sort_index()
assert not c.index.duplicated().any()
yc=c.average.astype(float).asfreq('MS'); invalid=(yc<=0)|yc.isna(); assert not invalid.any(), 'Missing target requires causal handling'
t=np.arange(len(yc)); cutoff=pd.Timestamp('2014-12-01'); train=yc.index<=cutoff; test=~train
# Descriptive annual linear trend with calendar-month effects.
D=pd.get_dummies(yc.index.month,drop_first=True,dtype=float).to_numpy()
design=np.column_stack([np.ones(len(t)),t/12,D]); ols=sm.OLS(yc.to_numpy()[train],design[train]).fit(); full=sm.OLS(yc.to_numpy(),design).fit()
resid=yc.to_numpy()[train]- (ols.params[0]+ols.params[1]*t[train]/12)
season=pd.Series(resid,index=yc.index[train]).groupby(lambda d:d.month).mean(); season-=season.mean()
fig,ax=plt.subplots(2,1,figsize=(9,5.5)); ax[0].plot(yc.index,yc,lw=.8); ax[0].axvline(cutoff,color='black',ls='--',lw=1); ax[0].set(ylabel='Monthly CO₂ (ppm)',title='Mauna Loa monthly CO₂; dashed line marks training cutoff'); ax[1].plot(range(1,13),season.values,'o-'); ax[1].set(xticks=range(1,13),xlabel='Month',ylabel='Detrended seasonal effect (ppm)',title='Seasonal pattern estimated from training data'); save('b_exploration.png')
def features(s):
 f=pd.DataFrame(index=s.index); f['lag1']=s.shift(1); f['lag12']=s.shift(12); f['mean3']=s.shift(1).rolling(3).mean(); f['mean12']=s.shift(1).rolling(12).mean(); f['growth12']=s.shift(1)-s.shift(13); f['trend']=np.arange(len(s))/12; f['sin12']=np.sin(2*np.pi*s.index.month/12); f['cos12']=np.cos(2*np.pi*s.index.month/12); return f
f=features(yc); valid=f.notna().all(axis=1); tr=train&valid; te=test&valid
# Fixed alpha, fixed feature set, no test-based tuning or refitting.
ridge=make_pipeline(StandardScaler(),Ridge(alpha=1.0)).fit(f.loc[tr],yc.loc[tr])
lin=LinearRegression().fit(design[train,1:],yc.loc[train])
preds={'Persistence':yc.shift(1).loc[te].to_numpy(),'Seasonal naive':yc.shift(12).loc[te].to_numpy(),'Trend + month OLS':lin.predict(design[te,1:]),'Feature ridge':ridge.predict(f.loc[te])}
scores={k:{'MAE':float(mean_absolute_error(yc.loc[te],a)),'RMSE':float(np.sqrt(mean_squared_error(yc.loc[te],a)))} for k,a in preds.items()}
# Full holdout recursive predictions from Dec 2014; no observed test updates.
history=yc.copy(); history.loc[test]=np.nan
for idx in yc.index[test]:
 row=features(history).loc[[idx]]; history.loc[idx]=ridge.predict(row)[0]
recursive={'MAE':float(mean_absolute_error(yc.loc[test],history.loc[test])),'RMSE':float(np.sqrt(mean_squared_error(yc.loc[test],history.loc[test])))}
fig,ax=plt.subplots(2,1,figsize=(9,5.5),sharex=True); ax[0].plot(yc.loc[test],color='black',label='Observed',lw=1.4)
for key in ['Seasonal naive','Trend + month OLS','Feature ridge']: ax[0].plot(yc.index[test],preds[key],label=key,lw=.9,alpha=.8)
ax[0].set(ylabel='CO₂ (ppm)',title='Test forecasts: January 2015 onward'); ax[0].legend(fontsize=8,ncol=2)
for key in ['Trend + month OLS','Feature ridge']: ax[1].plot(yc.index[test],yc.loc[test].to_numpy()-preds[key],label=key,lw=.9)
ax[1].axhline(0,color='black',lw=.7); ax[1].set(ylabel='Observed − forecast (ppm)',xlabel='Date'); ax[1].legend(fontsize=8); save('b_forecasts.png')
fig,ax=plt.subplots(figsize=(8,3)); ax.plot(yc.loc[test],label='Observed',color='black'); ax.plot(history.loc[test],label='Recursive ridge from Dec 2014'); ax.set(ylabel='CO₂ (ppm)',xlabel='Date',title='Sensitivity to forecast origin'); ax.legend(); save('b_recursive.png')
pd.DataFrame({'observed':yc.loc[te],**preds,'Recursive ridge':history.loc[te]}).to_csv(BASE/'forecast_results.csv')
R={'A':{'n_total':len(p),'n_complete':len(v),'variance':pc.explained_variance_ratio_.tolist(),'eigenvalues':pc.explained_variance_.tolist(),'weights':pc.components_[:2].T.tolist(),'correlations':np.corrcoef(np.column_stack([z,u]).T)[:4,4:].tolist(),'ks':ks,'inertia':inertia,'silhouettes':sil,'models':models,'species':species},'B':{'start':str(yc.index.min().date()),'end':str(yc.index.max().date()),'n':len(yc),'n_train':int(train.sum()),'n_model_train':int(tr.sum()),'n_test':int(test.sum()),'invalid':int(invalid.sum()),'slope_train':float(ols.params[1]),'slope_full':float(full.params[1]),'season':season.to_dict(),'amplitude':float(season.max()-season.min()),'peak':int(season.idxmax()),'trough':int(season.idxmin()),'scores':scores,'recursive':recursive},'hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (BASE/'data').glob('*.csv')}}
(BASE/'results.json').write_text(json.dumps(R,indent=2)); print(json.dumps(R,indent=2))
